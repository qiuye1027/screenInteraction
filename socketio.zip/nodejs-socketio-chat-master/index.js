var app = require('express')();
var express = require('express');
var fs = require('fs')
var path = require('path')
var http = require('http').Server(app);
var io = require('socket.io')(http);
var ss = require('socket.io-stream');
var port = process.env.PORT || 3000;

app.get('/', function(req, res){
  res.sendFile(__dirname + '/index.html');
});

app.use('/static',express.static('static'));
 


var multiparty = require('multiparty');
 


app.post('/uploadfile', function(req, res, next){
 //生成multiparty对象，并配置上传目标路径
    var form = new multiparty.Form({uploadDir: './sendfile/'});


     


    //上传完成后处理
    form.parse(req, function(err, fields, files) {
      var filesTmp = JSON.stringify(files,null,2);
  
      if(err){
        console.log('parse error: ' + err);
      } else {
        
        var inputFile = files.sampleFile[0];
        var uploadedPath = inputFile.path;
        var dstPath = './sendfile/' + inputFile.originalFilename;
        //重命名为真实文件名
        fs.rename(uploadedPath, dstPath, function(err) {
          if(err){
            console.log('rename error: ' + err);
          } else {
            console.log('rename ok----' +dstPath);
          }
        });
      }
  
       
   });
});






io.on('connection', function(socket){
  socket.on('chat message', function(msg){
  	
    io.emit('chat message', msg);
  });

   ss(socket).on('file', function(stream,data) {

  	 var filename = path.basename(data.name); 
    stream.pipe(fs.createWriteStream('./sendfile/'+filename));






 // 	var blobStream = ss.createBlobReadStream(stream);
	// var size = 0;

	// blobStream.on('data', function(chunk) {
	//   size += chunk.length;
	//   console.log(Math.floor(size / data.size * 100) + '%');
	//   // -> e.g. '42%'
	// });

	// blobStream.pipe(stream);





  });



 













});

http.listen(port, function(){
  console.log('listening on *:' + port);
});
